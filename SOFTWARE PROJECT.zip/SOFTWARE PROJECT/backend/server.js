const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const User = require("./models/User");
const Request = require("./models/Request");
const auth = require("./middleware/auth");

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 5000;
const SECRET_KEY = process.env.SECRET_KEY || "mysecretkey";

// ✅ MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/roadAssist", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB connected"))
.catch((err) => console.error("❌ MongoDB error:", err));

// ==================== AUTH ROUTES ====================

// 📝 Signup
app.post("/signup", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "All fields required" });

    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ email, password: hashedPassword });
    await newUser.save();

    const token = jwt.sign({ id: newUser._id }, SECRET_KEY, { expiresIn: "2h" });
    res.json({ message: "Signup successful", token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🔑 Login
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "All fields required" });

    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, SECRET_KEY, { expiresIn: "2h" });
    res.json({ message: "Login successful", token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== REQUEST ROUTES ====================

// 📌 Create a new breakdown request (protected)
app.post("/requests", auth, async (req, res) => {
  try {
    const { serviceType, location, description } = req.body;
    if (!serviceType || !location) {
      return res.status(400).json({ message: "Service type and location are required" });
    }

    const newRequest = new Request({
      user: req.user.id,
      serviceType,
      location,
      description,
      status: "Pending"
    });

    await newRequest.save();
    res.json({ message: "Request submitted successfully", request: newRequest });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 Get all requests of logged-in user
app.get("/requests", auth, async (req, res) => {
  try {
    const requests = await Request.find({ user: req.user.id });
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 Admin: Get all requests
app.get("/admin/requests", async (req, res) => {
  try {
    const requests = await Request.find().populate("user", "email");
    res.json(requests);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 Admin: Update request status
app.put("/admin/requests/:id", async (req, res) => {
  try {
    const { status } = req.body;
    const request = await Request.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );
    res.json({ message: "Request updated", request });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== START SERVER ====================
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
